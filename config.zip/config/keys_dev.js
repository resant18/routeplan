module.exports = {
  mongoURI:
    "mongodb+srv://dbAdmin:QfYYudtmYxYrIYR9@cluster0-igyvw.mongodb.net/test?retryWrites=true&w=majority",
  secretOrKey: "VJ6I1687Ip", // jsonwebtoken key
  mapApi: "GtJj838k2uUMChaJbStq3F7qM0WobjXf"
};
